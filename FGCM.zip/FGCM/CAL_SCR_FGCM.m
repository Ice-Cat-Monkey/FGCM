% % This is the MATLAB code for the paper:
% % 
% % A Fast Global Contrast Method for Infrared Small Dim Target Detection, IEEE TGRS, 2026
% % 
% % Run the file named "CAL_SCR_FGCM.m", the processing results will be shown step by step, and the value of SCRG and BSF can be found in the Command Window of MATLAB.
% % 
% % A sample image from SIRST dataset is provided for test here.  Users can replace test images by themselves.
% % 
% % The code has been verified under MATLAB R2020b.


clear all
close all
clc
DEBUG=1;  % if DEBUG==1, the processing result will be shown step by step
%% Parameter setting
start=139;  % read the 139th image from SIRST dataset
num=1;  % totally one image is read

wtype='db1';  % wavelet basis
r_dila=4;  % dilation radius for LMD operation

GAUS=[1 2 1; 2 4 2; 1 2 1]./16; % Gaussian template in Eq. 7 and Fig. 5

tao=5;  % tao in Eq. 8



r=9; % target area and neighboring area for SCRG and BSF calculation
nbr=15;


rth=5; % area for real target searching

TK=5; %  MDoG templates construction, totally 4 templates
TH=1./256.*[1 4 6 4 1
    4 16 24 16 4
    6 24 36 24 6
    4 16 24 16 4
    1 4 6 4 1];
TL=ones(TK,TK)./TK./TK;

CTR1=[0 0 1 1 1
    0 0 1 1 1
    0 0 1 1 1
    0 0 0 0 0
    0 0 0 0 0];
CTR2=rot90(CTR1);
CTR3=rot90(CTR2);
CTR4=rot90(CTR3);


TH1=TH.*CTR1./sum(sum(TH.*CTR1));
TL1=TL.*CTR1./sum(sum(TL.*CTR1));
DOG1=TH1-TL1;

TH2=TH.*CTR2./sum(sum(TH.*CTR2));
TL2=TL.*CTR2./sum(sum(TL.*CTR2));
DOG2=TH2-TL2;

TH3=TH.*CTR3./sum(sum(TH.*CTR3));
TL3=TL.*CTR3./sum(sum(TL.*CTR3));
DOG3=TH3-TL3;

TH4=TH.*CTR4./sum(sum(TH.*CTR4));
TL4=TL.*CTR4./sum(sum(TL.*CTR4));
DOG4=TH4-TL4;


load han_tgt_center1.mat %load target center data
load han_tgt_center2.mat %load target center data
load han_tgt_center3.mat %load target center data
load han_tgt_center4.mat %load target center data
load han_tgt_center5.mat %load target center data
load han_tgt_center6.mat %load target center data
load han_tgt_center7.mat %load target center data


%% Proccessing
ct=0;
tic
total_pixel=0;
for p=start:1:start+num-1
    ct=ct+1;
    ct

    
    IMG_org=(imread(['Misc_',num2str(p),'.png']));  % read image file
    if size(IMG_org, 3) == 3
        IMG_org=rgb2gray(IMG_org);
    end
    IMG_org=double(IMG_org);
    [M N]=size(IMG_org);
    if DEBUG==1
        IMG_show=IMG_org;
        figure;
        imshow(IMG_show,[min(min(IMG_show)) max(max(IMG_show))]);
        title('IMG ORG')
    end
    
    
    it=han_tgt_center1(p,1);  % orignal SCR
    jt=han_tgt_center1(p,2);
    
    IT=max(max(IMG_org(it-r:it+r,jt-r:jt+r)));
    IWH=max(max(IMG_org));
    SIGMAWH=std2(IMG_org);
    INB=(sum(sum(IMG_org(it-nbr:it+nbr,jt-nbr:jt+nbr)))-sum(sum(IMG_org(it-r:it+r,jt-r:jt+r))))./((nbr.*2+1).^2-(r.*2+1).^2);
    SCR=(IT-INB)./SIGMAWH;

    [M_org N_org]=size(IMG_org);
    total_pixel=total_pixel+M_org*N_org;
    
    
    IMG_GAUS=zeros(M_org,N_org);   % Gaussian filtering   
    for i=2:1:M_org-1
        for j=2:1:N_org-1
            IMG_GAUS(i,j)=sum(sum(IMG_org(i-1:i+1,j-1:j+1).*GAUS));
        end
    end
    if DEBUG==1
        IMG_show=IMG_GAUS;
        figure;
        imshow(IMG_show,[min(min(IMG_show)) max(max(IMG_show))]);
        title('IMG GAUS')
    end
    
    %% MDDOG
    IMG_DOG1=zeros(M_org,N_org);
    for i=3:1:M_org-2
        for j=3:1:N_org-2
            IMG_DOG1(i,j)=max(0,sum(sum(IMG_org(i-2:i+2,j-2:j+2).*DOG1)));
        end
    end    
    IMG_DOG2=zeros(M_org,N_org);
    for i=3:1:M_org-2
        for j=3:1:N_org-2
            IMG_DOG2(i,j)=max(0,sum(sum(IMG_org(i-2:i+2,j-2:j+2).*DOG2)));
        end
    end
    IMG_DOG3=zeros(M_org,N_org);
    for i=3:1:M_org-2
        for j=3:1:N_org-2
            IMG_DOG3(i,j)=max(0,sum(sum(IMG_org(i-2:i+2,j-2:j+2).*DOG3)));
        end
    end
    IMG_DOG4=zeros(M_org,N_org);
    for i=3:1:M_org-2
        for j=3:1:N_org-2
            IMG_DOG4(i,j)=max(0,sum(sum(IMG_org(i-2:i+2,j-2:j+2).*DOG4)));
        end
    end
    
    
    IMG_MDDOG=zeros(M_org,N_org);     % MDOG calculation according to Eq. 13
    for i=3:1:M_org-2
        for j=3:1:N_org-2
            DOGTMP=[IMG_DOG1(i,j),IMG_DOG2(i,j),IMG_DOG3(i,j),IMG_DOG4(i,j)];
            IMG_MDDOG(i,j)=max(0,min(DOGTMP));
        end
    end
    
    
    if DEBUG==1
        IMG_show=IMG_MDDOG;
        figure;
        imshow(IMG_show,[min(min(IMG_show)) max(max(IMG_show))]);
        title('IMG MDDOG')
        figure;
        mesh(IMG_show)
    end

    
    %% Wavelet decomposition, totally 3 layers
    [c,s]=wavedec2(IMG_org,3,wtype);
    [cH1,cV1,cD1]=detcoef2('all',c,s,1);
    cA1=appcoef2(c,s,wtype,1);
    [M_div N_div]=size(cA1);

    if DEBUG==1
        figure;
        imshow(cA1,[])
        title('cA1');
        figure;
        imshow(cH1,[])
        title('cH1');
        figure;
        imshow(cV1,[])
        title('cV1');
        figure;
        imshow(cD1,[])
        title('cD1');
    end
    
    DETAIL=idwt2(zeros(size(cA1)),cH1,cV1,cD1,wtype);
    if DEBUG==1
        figure;
        imshow(DETAIL,[])
        title('DETAIL IMAGE, LEVEL 1')
    end
    
    BK=idwt2(cA1,zeros(size(cH1)),zeros(size(cV1)),zeros(size(cD1)),wtype);
    if DEBUG==1
        figure;
        imshow(BK,[])
        title('BK IMAGE, LEVEL 1')
    end
    
    
    
    [cH2,cV2,cD2]=detcoef2('all',c,s,2);
    cA2=appcoef2(c,s,wtype,2);
    [M_div2 N_div2]=size(cA2);
    BK1=wrcoef2('a',c,s,wtype,1);

    BK2=wrcoef2('a',c,s,wtype,2);
    if DEBUG==1
        IMG_show=BK1;
        figure;
        imshow(IMG_show,[min(min(IMG_show)) max(max(IMG_show))]);
        title('IMG BK1')
        IMG_show=BK2;
        figure;
        imshow(IMG_show,[min(min(IMG_show)) max(max(IMG_show))]);
        title('IMG BK2')
    end
    
    [cH3,cV3,cD3]=detcoef2('all',c,s,3);
    cA3=appcoef2(c,s,wtype,3);
    [M_div3 N_div3]=size(cA3);
    
    BK3=wrcoef2('a',c,s,wtype,3);
    if DEBUG==1
        
        IMG_show=BK3;
        figure;
        imshow(IMG_show,[min(min(IMG_show)) max(max(IMG_show))]);
        title('IMG BK3')
    end
    
    alpha1=1;
    alpha2=2;
    alpha3=4;
    BK=(BK1.*alpha1+BK2.*alpha2+BK3.*alpha3)./(alpha1+alpha2+alpha3);% construct global background image according to Eq. 6
    
    %% LMD
    BK_DILA=IMG_org;

    for i=r_dila+1:1:M_org-r_dila
        for j=r_dila+1:1:N_org-r_dila
            BK_DILA(i,j)=max(max(BK(i-r_dila:i+r_dila,j-r_dila:j+r_dila)));
        end
    end
    
    if DEBUG==1
        IMG_show=BK_DILA;
        figure;
        imshow(IMG_show,[min(min(IMG_show)) max(max(IMG_show))]);
        title('IMG BK DILA')
        figure;
        mesh(IMG_show)
    end
    %% FGCM calculation
    FGCMXB=zeros(M_org,N_org);

    FGCMXB=IMG_GAUS.*(IMG_GAUS-BK_DILA)./max(tao,BK_DILA);  % FGCM according to Eq. 8, Eq. 9 and Eq. 10
    FGCMXB=max(0,FGCMXB);
    if DEBUG==1
        IMG_show=FGCMXB;
        figure;
        imshow(IMG_show,[]);
        title('FGCMXB')
        figure;
        mesh(IMG_show)
    end
    
    %% Weighting according to Eq. 15
    FGCMXB=mat2gray(FGCMXB);
    IMG_MDDOG=mat2gray(IMG_MDDOG);
    
    RDLCM_WEIGHT=FGCMXB.*IMG_MDDOG;
    if DEBUG==1
        IMG_show=RDLCM_WEIGHT;
        figure;
        imshow(IMG_show,[min(min(IMG_show)) max(max(IMG_show))]);
        title('FGCMXB.*IMG_MDDOG')
        figure;
        mesh(IMG_show)
    end
    
    RDLCM_WEIGHT_CUT=RDLCM_WEIGHT;  
 
    if DEBUG==1
        IMG_show=RDLCM_WEIGHT_CUT;
        figure;
        imshow(IMG_show,[min(min(IMG_show)) max(max(IMG_show))]);
        title('RDLCM WEIGHT')
        figure;
        mesh(IMG_show)
    end
    BERDLCM_CUT=RDLCM_WEIGHT_CUT;
    
    [M_CUT N_CUT]=size(BERDLCM_CUT);
    save(['FGCM_BERDLCM_CUT_',num2str(ct),'.mat'], 'BERDLCM_CUT', 'M_org', 'N_org', 'M_CUT', 'N_CUT')
         %%  SCRG and BSF calculation
        it=han_tgt_center1(p,1);
        jt=han_tgt_center1(p,2);
        IT=max(max(BERDLCM_CUT(it-r:it+r,jt-r:jt+r,ct)));

        SIGMAWHOUT=std2(BERDLCM_CUT(:,:,ct));
        INB=(sum(sum(BERDLCM_CUT(it-nbr:it+nbr,jt-nbr:jt+nbr,ct)))-sum(sum(BERDLCM_CUT(it-r:it+r,jt-r:jt+r,ct))))./((nbr.*2+1).^2-(r.*2+1).^2);
        SCROUT=(IT-INB)./SIGMAWHOUT;
        SCRG=SCROUT./SCR
        BSF=SIGMAWH./SIGMAWHOUT


   
end
[M_CUT N_CUT]=size(BERDLCM_CUT(:,:,1));

%% DETECTION
pd=0;
pf=0;
kthsav=0;
for kth=1:-0.05:1
    num_sus_tgt=0;% suspect target number
    num_true_tgt=0;% true target number 

    for ct=1:1:num
        
        load(['FGCM_BERDLCM_CUT_',num2str(ct),'.mat'])
        BERDLCM_CUT_TMP=BERDLCM_CUT;
        p=ct+start-1;
        meanmean=mean(mean(BERDLCM_CUT_TMP));% threshold
        maxmax=max(max(BERDLCM_CUT_TMP));
        TH=maxmax.*kth+(1-kth).*meanmean;
          

        MASK=zeros(M_org,N_org);%MASK
        for i=1:1:M_CUT
            for j=1:1:N_CUT
                if BERDLCM_CUT_TMP(i,j)>=TH
                    MASK(i,j)=1;
                end
            end
        end
        
        SE=strel('square',5);
        MASK=imdilate(MASK,SE);
        CNC=bwconncomp(MASK); % number of detected target
        num_sus_tgt=num_sus_tgt+CNC.NumObjects;
            %% count true target number
            if han_tgt_center1(p,1) > 0 && han_tgt_center1(p,2) > 0 % if target exist
                if sum(sum(MASK(max(1,han_tgt_center1(p,1)-rth):min(han_tgt_center1(p,1)+rth,M_CUT),max(1,han_tgt_center1(p,2)-rth):min(han_tgt_center1(p,2)+rth,N_CUT))))>0
                    num_true_tgt=num_true_tgt+1;
                end
            end
            if han_tgt_center2(p,1) > 0 && han_tgt_center2(p,2) > 0 
                if sum(sum(MASK(max(1,han_tgt_center2(p,1)-rth):min(han_tgt_center2(p,1)+rth,M_CUT),max(1,han_tgt_center2(p,2)-rth):min(han_tgt_center2(p,2)+rth,N_CUT))))>0
                    num_true_tgt=num_true_tgt+1;
                end
            end
             if han_tgt_center3(p,1) > 0 && han_tgt_center3(p,2) > 0 
                if sum(sum(MASK(max(1,han_tgt_center3(p,1)-rth):min(han_tgt_center3(p,1)+rth,M_CUT),max(1,han_tgt_center3(p,2)-rth):min(han_tgt_center3(p,2)+rth,N_CUT))))>0
                    num_true_tgt=num_true_tgt+1;
                end
             end
            if han_tgt_center4(p,1) > 0 && han_tgt_center4(p,2) > 0 
                if sum(sum(MASK(max(1,han_tgt_center4(p,1)-rth):min(han_tgt_center4(p,1)+rth,M_CUT),max(1,han_tgt_center4(p,2)-rth):min(han_tgt_center4(p,2)+rth,N_CUT))))>0
                    num_true_tgt=num_true_tgt+1;
                end
            end
             if han_tgt_center5(p,1) > 0 && han_tgt_center5(p,2) > 0 
                if sum(sum(MASK(max(1,han_tgt_center5(p,1)-rth):min(han_tgt_center5(p,1)+rth,M_CUT),max(1,han_tgt_center5(p,2)-rth):min(han_tgt_center5(p,2)+rth,N_CUT))))>0
                    num_true_tgt=num_true_tgt+1;
                end
             end
            if han_tgt_center6(p,1) > 0 && han_tgt_center6(p,2) > 0
                if sum(sum(MASK(max(1,han_tgt_center6(p,1)-rth):min(han_tgt_center6(p,1)+rth,M_CUT),max(1,han_tgt_center6(p,2)-rth):min(han_tgt_center6(p,2)+rth,N_CUT))))>0
                    num_true_tgt=num_true_tgt+1;
                end
            end
            if han_tgt_center7(p,1) > 0 && han_tgt_center7(p,2) > 0 
                if sum(sum(MASK(max(1,han_tgt_center7(p,1)-rth):min(han_tgt_center7(p,1)+rth,M_CUT),max(1,han_tgt_center7(p,2)-rth):min(han_tgt_center7(p,2)+rth,N_CUT))))>0
                    num_true_tgt=num_true_tgt+1;
                end
            end

        
        
        if DEBUG==1  %detected result
            IMG_DET=MASK;

            IMG_show=IMG_DET;
            figure;
            imshow(IMG_show,[min(min(IMG_show)) max(max(IMG_show))]);
        end

         
    end
    toc
    
%     pd_single_th=num_true_tgt./535;
%     pf_single_th=(num_sus_tgt-num_true_tgt)./(total_pixel-535);
%     
%     m_pd=size(pd);
%     if pd_single_th>pd(m_pd)
%         pd=[pd pd_single_th];
%         pf=[pf pf_single_th];
%         kthsav=[kthsav kth];
%     end
end
